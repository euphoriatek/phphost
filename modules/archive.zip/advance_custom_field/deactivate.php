<?php

defined('BASEPATH') or exit('No direct script access allowed');

update_option("acf_onn", "0");