<div class="kan-ban-tab" id="kan-ban-tab">
   <div class="row">
      <div class="container-fluid">
         <div id="kan-ban"></div>
      </div>
   </div>
</div>