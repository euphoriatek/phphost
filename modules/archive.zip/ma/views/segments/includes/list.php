<table class="table table-segments">
  <thead>
    <th><?php echo _l('name'); ?></th>
    <th><?php echo _l('leads'); ?></th>
    <th><?php echo _l('category'); ?></th>
    <th><?php echo _l('published'); ?></th>
  </thead>
  <tbody>
  </tbody>
</table>