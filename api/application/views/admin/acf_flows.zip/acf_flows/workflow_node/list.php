<table class="table table-campaigns">
   <thead>
      <tr>
         <th><?php echo _l('name'); ?></th>
         <th><?php echo _l('published'); ?></th>
      </tr>
   </thead>
</table>